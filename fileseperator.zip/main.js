    function addColor(extension, color) {
        addColor[extension]{
           color: color
        };
    }
    //Ruby//
    addColor ('rb', '#E80C7A') ;

    //JavaScript//
    addColor ('js', '#D34200') ;

    //HTML//
    addColor ('html', '#E72800') ;

    //CSS//
    addColor ('css', '#0026FF') ;

    //Python//
    addColor ('py', '#00C5FF') ;

    //Markdown//
    addColor ('md', '#FFA300') ;

    //LESS//
    addColor ('less', '#009AE8') ;

    //C#//
    addColor ('cs', '#A7E8C6') ;

    //C++//
    addColor ('c++', '#CFBCE8') ;

    //Clojure//
    addColor ('clj', '#52E800') ;

    //CoffeeScript//
    addColor ('coffee', '#5C00E8') ;

    //Dart//
    addColor ('dart', '#00E86D') ;

    //Go//
    addColor ('go', '#00D999') ;

    //Groovy//
    addColor ('groovy', '#5569E8') ;

    //Haskell//
    addColor ('hs', '#D5E0E8') ;

    //Haxe//
    addColor ('hx', '#E83E00') ;

    //Java//
    addColor ('java', '#E83E00') ;

    //JSON//
    addColor ('json', '#F0A5FF') ;

    //PHP//
    addColor ('php', '#BE00FF') ;

    //SCSS//
    addColor ('scss', '#FF00FE') ;

    //Swift//
    addColor ('swift', '#FFA45E') ;